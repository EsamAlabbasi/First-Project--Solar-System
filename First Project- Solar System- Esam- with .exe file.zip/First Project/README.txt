First-Project--Solar-System
===========================
https://github.com/EsamAlabbasi/First-Project--Solar-System


First Project- Solar System

Merhaba hocam

In the .exe application the solar system appeared without the texture, but in the project the texturing was appearing well!!
I dont know the problem of this, but you can use the source code and compile it to view the final project

 
Thank you very much

Esam Ghaleb
040080905